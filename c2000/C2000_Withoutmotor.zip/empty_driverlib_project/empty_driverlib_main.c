// -------------------------------------------------------------
// C2000 F28379D LaunchPad - SCI-B (Harici USB-TTL) - HIGH SPEED
// -------------------------------------------------------------

#include "driverlib.h"
#include "device.h"

// Fonksiyon Prototipleri
void initADC(void);
void initSCIB(void);

void main(void)
{
    // LED Sayaci degiskeni (En basta tanimlanmali)
    uint16_t ledSayac = 0;

    // 1. Cihaz ve Clock Ayarlari
    Device_init();
    Device_initGPIO();

    // 2. LED Ayari
    GPIO_setPadConfig(DEVICE_GPIO_PIN_LED1, GPIO_PIN_TYPE_STD);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_LED1, GPIO_DIR_MODE_OUT);

    // 3. Interruptlari Kapat
    Interrupt_initModule();
    Interrupt_initVectorTable();

    // 4. Modulleri Baslat
    initADC();
    initSCIB();

    // 5. Global Interruptlari Ac
    EINT;
    ERTM;

    // --- SONSUZ DONGU (MAKSIMUM HIZ) ---
    while(1)
    {
        // A) ADC Donusumunu Baslat
        ADC_forceSOC(ADCA_BASE, ADC_SOC_NUMBER0);

        // B) Donusum Bitene Kadar Bekle
        while(ADC_getInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1) == 0)
        {
            // Bekliyor...
        }
        ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);

        // C) Sonucu Oku
        uint16_t adcResult = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0);

        // D) Veriyi Gonder (HIZ SINIRI BURADA)
        // SCI Buffer dolana kadar basar, delay yoktur.
        SCI_writeCharBlockingFIFO(SCIB_BASE, (adcResult >> 8) & 0xFF);
        SCI_writeCharBlockingFIFO(SCIB_BASE, adcResult & 0xFF);

        // E) LED Yak/Sondur (Her 5000 veride bir)
        // Cunku delay olmadigi icin saniyede binlerce kez donecek.
        ledSayac++;
        if(ledSayac > 5000)
        {
            GPIO_togglePin(DEVICE_GPIO_PIN_LED1);
            ledSayac = 0;
        }
    }
}

// --- ADC AYARLARI ---
void initADC(void)
{
    ADC_setPrescaler(ADCA_BASE, ADC_CLK_DIV_4_0);
    ADC_setMode(ADCA_BASE, ADC_RESOLUTION_12BIT, ADC_MODE_SINGLE_ENDED);
    ADC_setInterruptPulseMode(ADCA_BASE, ADC_PULSE_END_OF_CONV);
    ADC_enableConverter(ADCA_BASE);
    DEVICE_DELAY_US(1000);

    // ADCINA0 (Pin 30) Ayari
    ADC_setupSOC(ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY, ADC_CH_ADCIN0, 15);
    ADC_setInterruptSource(ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
    ADC_enableInterrupt(ADCA_BASE, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);
}

// --- SCI-B (UART) AYARLARI ---
void initSCIB(void)
{
    // GPIO 18 (TX) ve GPIO 19 (RX)
    GPIO_setPinConfig(GPIO_18_SCITXDB);
    GPIO_setPinConfig(GPIO_19_SCIRXDB);

    GPIO_setDirectionMode(18, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(18, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(18, GPIO_QUAL_ASYNC);

    GPIO_setDirectionMode(19, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(19, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(19, GPIO_QUAL_ASYNC);

    // 115200 Baud Rate (_LAUNCHXL_F28379D sembolu sart!)
    SCI_setConfig(SCIB_BASE, DEVICE_LSPCLK_FREQ, 115200, (SCI_CONFIG_WLEN_8 | SCI_CONFIG_STOP_ONE | SCI_CONFIG_PAR_NONE));
    SCI_resetChannels(SCIB_BASE);
    SCI_resetRxFIFO(SCIB_BASE);
    SCI_resetTxFIFO(SCIB_BASE);
    SCI_enableModule(SCIB_BASE);
    SCI_enableFIFO(SCIB_BASE);
}

